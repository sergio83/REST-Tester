//
//  AppDelegate.h
//  TestSeviceExample
//
//  Created by Sergio Cirasa on 10/07/12.
//  Copyright (c) 2012 x. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
